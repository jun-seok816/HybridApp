function clickBtn(){
     var e = document.getElementById('aa');
     e.innerHTML=AndroidDevice.a;
     AndroidDevice.ShowLocation();

  }